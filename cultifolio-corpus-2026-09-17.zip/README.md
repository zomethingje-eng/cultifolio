# Cultifolio species reference, dataset 2026.09

103 species, 92 with a habitat climate. Built 2026-09-16 to 2026-09-16; packaged 2026-09-17.

This is the reference data behind https://cultifolio.com, packaged so it can be read, checked and reused without the app. Every figure in it was derived by the open-source build at https://github.com/zomethingje-eng/cultifolio from the public sources listed in LICENSE.md. Nothing in it was written by a person or a language model, and no figure the build could not derive was filled in: where a value is missing it is missing.

## What is here

`species/<slug>.json`
One file per species, exactly as the build wrote it: the accepted name and its synonyms (GBIF Backbone), native and introduced regions at TDWG level 3 (WCVP), the sampled in-range occurrence records the habitat centre was found from and how it was found, the climate at that centre month by month (CHELSA V2.1 normals; daily extremes from NASA POWER where they were usable), photo references with their licence and credit (links only; no image files are redistributed), literature references (OpenAlex), a Wikipedia summary, and an `upstream` section recording every request the build made, with its status, so a refusal can be told from an absence.

`species.csv`
One row per species: identifiers, name, family, regions, the habitat centre (latitude, longitude, how many records it rests on and what share of in-range records fell in its cluster), the climate status, annual precipitation at the centre, the growing season read from the rain and temperature curves (`summer`, `winter` or `even`; the months given in habitat time), the coldest month's mean minimum, the 1st-percentile daily minimum and frost days per year where extremes were usable, and counts. Empty cells are values the build could not derive.

`climate.csv`
Twelve rows per species with climate: mean daily maximum, minimum and mean temperature (°C), precipitation (mm), daily light integral (mol/m²/day) and relative humidity (%) at the habitat centre, month by month.

`index.json`
The list the app serves: key, slug, name, family, origin, photo count, count of open records and climate status.

`build-report.txt`
The build's own log for this corpus, when it was kept: which species were built, which sources refused and why.

## How the numbers were derived

The method is written up at https://cultifolio.com/about/how and is what the build implements. In short: names are matched to the GBIF Backbone; the native range comes from WCVP; occurrence records inside the native range are clustered at 1°, and the habitat centre is the record nearest the middle of the densest cluster, requiring at least three agreeing records; the climate is read at that point from CHELSA V2.1; the growing season is the smallest set of months carrying 70% of annual rain (or, under 120 mm a year, the cooler half of the year). Restricted-licence (CC BY-NC) records may inform the clustering but are never redistributed; every coordinate in `species/*.json` carries its own licence code.

## Citing

Cite the sources, not only this bundle: the figures are theirs. Each species file names the GBIF occurrence download it drew on (a DOI, under `upstream`), and the CHELSA, WCVP and NASA POWER citations are in LICENSE.md. For the derivation itself, cite the repository at https://github.com/zomethingje-eng/cultifolio and this dataset version.
