# Licence

## The derived figures

The habitat centres, growing seasons, cold floors, the CSV files, the index and the arrangement of this bundle are released under the Creative Commons Attribution 4.0 International licence (CC BY 4.0). Attribute "Cultifolio species reference, https://github.com/zomethingje-eng/cultifolio" and keep the source attributions below, which the figures rest on.

## The parts that keep their own licence

The bundle carries data from the sources below unchanged or lightly reshaped. Each keeps the licence it came under, and that licence governs reuse of that part.

| Part of the bundle | Source | Licence |
|---|---|---|
| `name`, `ids`, synonyms, vernacular names | GBIF Backbone Taxonomy | CC BY 4.0 |
| `occurrences.open` (coordinates; each row's last field is its own licence code: `cc0` or `by`) | GBIF occurrence records, dataset-by-dataset; the download DOI is under `upstream` | CC0 1.0 or CC BY 4.0 per record. CC BY-NC records were used to find the centre and are not included. |
| `distribution` (regions, boxes) | World Checklist of Vascular Plants, Royal Botanic Gardens, Kew (Govaerts et al.) | CC BY 4.0 |
| `climate.months`, `climate.cell` and `climate.csv` | CHELSA V2.1 (Karger et al.), read at one cell | CC0 1.0 |
| `climate.extremes` | NASA POWER daily data | Public domain (United States Government) |
| `summary.text` | Wikipedia, the article named in `summary.url` | CC BY-SA 4.0. Reuse of the text carries share-alike. Delete the `summary` field for a bundle free of it. |
| `photos` (URL, credit, licence; no image files) | iNaturalist and Wikimedia Commons, per photo | The licence named on each record: CC0, CC BY or CC BY-SA. The image itself is the photographer's and is not redistributed here. |
| `literature` | OpenAlex | CC0 1.0 |

## Citations

GBIF.org. GBIF Backbone Taxonomy and occurrence downloads; each species file names its download DOI under `upstream`.

Govaerts R, Nic Lughadha E, Black N, Turner R, Paton A. The World Checklist of Vascular Plants, a continuously updated resource for exploring global plant diversity. Scientific Data 8, 215 (2021). Royal Botanic Gardens, Kew.

Karger DN, Conrad O, Böhner J, et al. Climatologies at high resolution for the earth's land surface areas. Scientific Data 4, 170122 (2017). CHELSA V2.1.

NASA POWER Project. Prediction Of Worldwide Energy Resources, daily data. NASA Langley Research Center.

Wikipedia contributors; iNaturalist contributors; Wikimedia Commons contributors; OpenAlex (Priem J, Piwowar H, Orr R, 2022).

## Warranty

None. The figures are derived from records of where plants have been found and what the climate is there; they are not tested horticultural limits, and the bundle says so wherever a figure could be mistaken for one.
